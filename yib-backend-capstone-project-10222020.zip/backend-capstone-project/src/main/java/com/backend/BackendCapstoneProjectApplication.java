package com.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendCapstoneProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendCapstoneProjectApplication.class, args);
	}

}
